Originary brand kit · v17 · Carbon + Cobalt · 12 October 2026

wordmark/   Ink and reverse masters (SVG), PNG 240 to 3840 px wide
app-icon/   App icon and avatar tile, SVG and PNG 16 to 1024 px
favicon/    favicon.ico, favicon.svg, 32 px, apple-touch 180 px
social/     Avatar 400, link preview 1200x630, X header 1500x500, LinkedIn banner 1584x396
tokens/     originary-tokens.css: colour, type, spacing and motion tokens, light and dark

The wordmark is the logo. Reproduce it only from these files.
- Ink #0B0B0C on white and light greys; the reverse (white) file on ink and dark greys.
- Never recolour (not even in cobalt), stretch, outline, add effects, retype, re-space or rotate it,
  and never place it on mid-tones or photographs.
- Clear space: one x-height (about 1/8 of the wordmark's width) on every side.
- Minimum width 120 px on screen, 96 px at the very least. Below that, use the app icon.
- The app icon is a container, not a second logo. Do not place it beside the wordmark as a lockup.
- Text: Originary, with a capital O. IBM Plex Sans and IBM Plex Mono for everything but the logo.

Examples are interoperability surfaces, not partnership claims.
Originary is a trademark of Poem, Inc. Questions: contact@originary.xyz
